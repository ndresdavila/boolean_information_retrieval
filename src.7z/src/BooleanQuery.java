// DO NOT CHANGE THIS PACKAGE NAME.

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.nio.charset.StandardCharsets.ISO_8859_1;

public class BooleanQuery {
	public static Path plotPath;
	public static List<MV> movies = new ArrayList<MV>();
	public static Map<String, HashSet<Long>> index = new HashMap<>();
	public static Pattern pattern = Pattern
			.compile("mv: (\")?([^\"(]*)(\")? ?(\\((\\d{4}|\\?{4})(\\/\\w*)?\\))?( \\((vg|tv|v)\\))? ?(\\{(.*)\\})?");

	/**
	 * DO NOT CHANGE THE CONSTRUCTOR. DO NOT ADD PARAMETERS TO THE CONSTRUCTOR.
	 */
	public BooleanQuery() {
	}

	/**
	 * A method for reading the textual movie plot file and building indices. The
	 * purpose of these indices is to speed up subsequent boolean searches using the
	 * {@link #booleanQuery(String) booleanQuery} method.
	 * <p>
	 * DO NOT CHANGE THIS METHOD'S INTERFACE.
	 *
	 * @param plotFile the textual movie plot file 'plot.list' for personal,
	 *                 non-commercial use.
	 */
	public void buildIndices(Path plotFile) {
		MV mv = new MV();
		try (BufferedReader reader = Files.newBufferedReader(plotFile, ISO_8859_1)) {
			String line;
			String[] splitedLine = null;

			long lineNr = 0;
			long filmLine = 0;
			while ((line = reader.readLine()) != null) {
				lineNr++;

				if (line.startsWith("MV: ")) {
					movies.add(mv);
					mv = new MV();

					filmLine = mv.setLine(lineNr);
					mv.setCompleteName(line);

					Matcher matcher = pattern.matcher(line.toLowerCase());
					if (matcher.matches()) {
						mv.setName(matcher.group(2));
						mv.setYear(matcher.group(5));
						String chapter = matcher.group(10);
						if (chapter != null && !chapter.contains("SUSPENDED")) {
							mv.setEpisode(matcher.group(10));
						}

						// Init movie types
						if (matcher.group(1) == null && matcher.group(8) == null) {
							mv.setType(Type.MOVIE);
						}
						if (matcher.group(1) != null) {
							if (matcher.group(1).equals("\"") && matcher.group(9) == null) {
								mv.setType(Type.SERIES);
							}
							if (matcher.group(1).equals("\"") && mv.getEpisode() != null) {
								mv.setType(Type.EPISODE);
							}
						}
						if (matcher.group(8) != null) {
							if (matcher.group(8).equals("tv"))
								mv.setType(Type.TELEVISION);
							else if (matcher.group(8).equals("v"))
								mv.setType(Type.VIDEO);
							else if (matcher.group(8).equals("vg"))
								mv.setType(Type.VIDEOGAME);
						}
					}

				} else if (line.startsWith("PL:")) {
					// make the token list

					splitedLine = line.replace("PL: ", "").toLowerCase().split("[ .,:!?]");
					for (String word : splitedLine) {
						word = word.trim();
						// It saved empty string "" as a token when there is a space after an "."
						if (word == "")
							continue;
						if (index.get(word) == null) {
							HashSet<Long> words_set = new HashSet<Long>();
							words_set.add(filmLine);
							index.put(word, words_set);
						} else {
							index.get(word).add(filmLine);
						}
					}

				} else {
					continue;
				}

			}

		} catch (FileNotFoundException e) {
			System.err.println("ERROR: There was a problem finding the file");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("ERROR: There was a problem reading the file");
			e.printStackTrace();
		}
		movies.add(mv);
		movies.remove(0);
	}

	/**
	 * A method for performing a boolean search on a textual movie plot file after
	 * indices were built using the {@link #buildIndices(String) buildIndices}
	 * method. The movie plot file contains entries of the <b>types</b> movie,
	 * series, episode, television, video, and videogame. This method allows term
	 * and phrase searches (the latter being enclosed in double quotes) on any of
	 * the <b>fields</b> title, plot, year, episode, and type. Multiple term and
	 * phrase searches can be combined by using the character sequence " AND ". Note
	 * that queries are case-insensitive.<br>
	 * <br>
	 * Examples of queries include the following:
	 *
	 * <pre>
	 * title:"game of thrones" AND type:episode AND plot:shae AND plot:Baelish
	 * plot:Skywalker AND type:series
	 * plot:"year 2200"
	 * plot:Berlin AND plot:wall AND type:television
	 * plot:Cthulhu
	 * title:"saber rider" AND plot:april
	 * plot:"James Bond" AND plot:"Jaws" AND type:movie
	 * title:"Pimp my Ride" AND episodetitle:mustang
	 * plot:"matt berninger"
	 * title:"grand theft auto" AND type:videogame
	 * plot:"Jim Jefferies"
	 * plot:Berlin AND type:videogame
	 * plot:starcraft AND type:movie
	 * type:video AND title:"from dusk till dawn"
	 * </pre>
	 * 
	 * DO NOT CHANGE THIS METHOD'S INTERFACE.
	 *
	 * @param queryString the query string, formatted according to the Lucene query
	 *                    syntax, but only supporting term search, phrase search,
	 *                    and the AND operator
	 * @return the exact content (in the textual movie plot file) of the title lines
	 *         (starting with "MV: ") of the documents matching the query
	 */
	public Set<String> booleanQuery(String queryString) {

		List<Integer> phraseSearch = new ArrayList<>();
		HashMap<Long, Integer> helper = new HashMap<>();

		// 1. adds all query elements (separated with AND) to the list of elements
		String[] query_elements = queryString.split("AND");

		// 2. create field and token for every query element from the query
		String[] fields = new String[query_elements.length]; // list that stores every field
		String[] tokens = new String[query_elements.length]; // list that stores every token
		String[] query;

		for (int i = 0; i < query_elements.length; i++) {
			query = query_elements[i].replaceAll("\"", "").split(":");

			// divide query element into field and token
			fields[i] = query[0].toLowerCase().trim();
			tokens[i] = query[1].toLowerCase().trim();

			if (fields[i].equals("plot"))
				phraseSearch.add(i);
		}

		// check all the queries but the plot
		for (MV mov : movies) {
			int i = 0;
			for (String field : fields) {
				switch (field) { // TODO make shorter with if
				case "title":	
					if (mov.getName().toLowerCase().contains(tokens[i])) {
						helper.merge(mov.getLine(), 1, Integer::sum);
					}
					break;
				case "type":
					if (mov.getType().toString().toLowerCase().equals(tokens[i])) {
						helper.merge(mov.getLine(), 1, Integer::sum);
					}
					break;
				case "year":
					if (mov.getYear().equals(tokens[i])) {
						helper.merge(mov.getLine(), 1, Integer::sum);
					}
					break;
				case "episodetitle":
					if (mov.getEpisode().toLowerCase().contains(tokens[i])) {
						helper.merge(mov.getLine(), 1, Integer::sum);
					}
					break;
				case "plot":
					break;
				default:
					throw new IllegalArgumentException("ERROR: Uncorrect query");
				}
				i++;
			}
		}
		
		//for (String s : tokens) System.out.println(s);
		//for (String s : fields) System.out.println(s);
		int plotsNumber = phraseSearch.size();

		// make a shorter list of candidates before looking the plot
		Set<Long> filtered = helper.entrySet().stream().filter(
				entrySet -> entrySet.getValue() == (plotsNumber == 0 ? fields.length : fields.length - plotsNumber))
				.map(entrySet -> entrySet.getKey()).collect(Collectors.toSet());
		
		//for (Long l : filtered) System.out.println(l);
		//System.out.println("size before = " + filtered.size() + "plotsNumber = " + plotsNumber);
		Set<String> solution = new HashSet<>();
		if (plotsNumber != 0) {
			// phrase search

			List<Pattern> queryPatterns = new ArrayList<>();
			try (BufferedReader reader = Files.newBufferedReader(plotPath, ISO_8859_1)) {
				for (int i : phraseSearch) {

					String[] words = tokens[i].replaceAll("\"", "").split(" ");
					queryPatterns.add(Pattern.compile(String.join("\\W+", words)));

					for (String word : words) {
						// Intersection of the filtered and words sets: that means we are keeping just
						// the lines that we obtained before that have the searched words in the plot

						HashSet<Long> wordsSet = index.get(word.trim());
						if(wordsSet != null) {
							filtered.retainAll(index.get(word.trim()));
						}
					}
					//System.out.println("size after = " + filtered.size());
				}
				//for (Long l : filtered) System.out.println("Filtered: " + l);
				String line;
				String title = "-1";
				long lineCount = 1;

				if (!filtered.isEmpty()) {
					while ((line = reader.readLine()) != null && filtered.size() != 0) {
						if (line.startsWith("MV:")) title = line;
						if (filtered.contains(lineCount)) {
							// check if the words respect the order in the plot
							filtered.remove(lineCount);
							StringBuffer buffer = new StringBuffer();
							while ((line = reader.readLine()) != null && !line.startsWith("MV")) {
								if (line.startsWith("PL")) {
									buffer.append(line.substring(3).toLowerCase());
								}
								lineCount++;
							}
							//System.out.println("Buffer is: " + buffer.toString() + "\n");
							int counter = 0;
							for (Pattern queryPattern : queryPatterns) {
								Matcher matcher = queryPattern.matcher(buffer);
								if (!matcher.matches()) {
									counter++;
								}
							}
	
							if (counter == queryPatterns.size()) {
								//System.out.println("TITLE = " + title);
								solution.add(title);
							}
							//lineCount--; // TODO: look a fancier way to do it
						}
						lineCount++;
					}
				}
				// if there are only "plot" queries
				else {
					while ((line = reader.readLine()) != null) {
						if (line.startsWith("MV:")) {
							title = line;
							line = reader.readLine();
							StringBuffer buffer = new StringBuffer();
							while ((line = reader.readLine()) != null && !line.startsWith("--")) {
								if (line.startsWith("PL: ")) {
									buffer.append(line.substring(3).toLowerCase());
								}
							}
							int counter = 0;
							for (String tok : tokens) {
								if (buffer.toString().contains(tok)) counter++;
							}
	
							if (counter == tokens.length) {
								//System.out.println("TITLE = " + title);
								solution.add(title);
							}
						}
						else continue;
					}		
				}



			} catch (IOException e) {
				System.err.println("ERROR: There was a problem reading the file");
				e.printStackTrace();
			}

		} else {
			solution = movies.stream().filter(movie -> filtered.contains(movie.getLine()))
					.map(movie -> movie.getCompleteName()).collect(Collectors.toSet());
		}
		//for (String s : solution) System.out.println(s);
		return solution;
	}

	public static void setPath(Path path) {
		BooleanQuery.plotPath = path;
	}

	public static void main(String[] args) {
		BooleanQuery bq = new BooleanQuery();
		/*
		 * Changed for simplicity during development For final run: UNCOMMNENT THIS
		 */
//		if (args.length < 3) {
//			System.err.println("Usage: java -jar BooleanQuery.jar <plot list file> <queries file> <results file>");
//			System.exit(-1);
//		}

		/* And DELETE THIS */
		args = new String[] { "plot.list", "queries.txt", "results.txt" };

		Path moviePlotFile = Paths.get(args[0]);
		Path queriesFile = Paths.get(args[1]);
		Path resultsFile = Paths.get(args[2]);
		setPath(moviePlotFile);

		// build indices
		System.out.println("Building indices...");
		long tic = System.nanoTime();
		Runtime runtime = Runtime.getRuntime();
		long mem = runtime.totalMemory();
		bq.buildIndices(moviePlotFile);

		System.out.println("Runtime: " + (System.nanoTime() - tic) + " nanoseconds");
		System.out.println("Memory: " + ((runtime.totalMemory() - mem) / (1048576L)) + " MB (rough estimate)");

		// parsing the queries that are to be run from the queries file
		List<String> queries = new ArrayList<>();
		try (BufferedReader reader = Files.newBufferedReader(queriesFile, ISO_8859_1)) {
			String line;
			while ((line = reader.readLine()) != null) {
				queries.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}

		// parsing the queries' expected results from the results file
		List<Set<String>> results = new ArrayList<>();
		try (BufferedReader reader = Files.newBufferedReader(resultsFile, ISO_8859_1)) {
			String line;
			while ((line = reader.readLine()) != null) {
				Set<String> result = new HashSet<>();
				results.add(result);
				for (int i = 0; i < Integer.parseInt(line); i++) {
					result.add(reader.readLine());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}

		// run queries
		for (int i = 0; i < queries.size(); i++) {
			String query = queries.get(i);
			Set<String> expectedResult = i < results.size() ? results.get(i) : new HashSet<>();
			System.out.println();
			System.out.println("Query:           " + query);
			tic = System.nanoTime();
			Set<String> actualResult = bq.booleanQuery(query);

			// sort expected and determined results for human readability
			List<String> expectedResultSorted = new ArrayList<>(expectedResult);
			List<String> actualResultSorted = new ArrayList<>(actualResult);
			Comparator<String> stringComparator = Comparator.naturalOrder();
			expectedResultSorted.sort(stringComparator);
			actualResultSorted.sort(stringComparator);

			System.out.println("Runtime:         " + (System.nanoTime() - tic) + " nanoseconds.");
			System.out.println("Expected result: " + expectedResultSorted.toString());
			System.out.println("Actual result:   " + actualResultSorted.toString());
			System.out.println(expectedResult.equals(actualResult) ? "SUCCESS" : "FAILURE");
		}
	}

}
